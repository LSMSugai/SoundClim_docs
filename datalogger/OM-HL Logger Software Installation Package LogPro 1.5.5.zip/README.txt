LogPro version  infomation   
---------------------- 
1.5.1,2018-9-22 ,support OM-HL-SP series
1.5.2,2018-10-22,Add support OM-HL-SH series
1.5.3,2019-11-15,Improve configuration information validation
1.5.4,2019-01-08,Update connect function
1.5.5,2019-02-05,Add support OM-HL-EH-TC
-------------
Copyright (C) 2007-2019. All rights reserved.

